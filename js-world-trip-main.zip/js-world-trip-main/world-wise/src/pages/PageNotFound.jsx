import PageNav from "../components/PageNav";

function PageNotFound() {
  return (
    <div>
      <PageNav />
      Not found :(
    </div>
  );
}

export default PageNotFound;
