import PageNav from "../components/PageNav";

function Pricing() {
  return (
    <div>
      <PageNav />
      <h1>Pricing</h1>
    </div>
  );
}

export default Pricing;
